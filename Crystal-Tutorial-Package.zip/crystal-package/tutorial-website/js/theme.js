// Copyright (c) 2026 Kyle Blizzard. All Rights Reserved.
// This code is publicly visible for portfolio purposes only.
// Unauthorized copying, forking, or distribution of this file,
// via any medium, is strictly prohibited.

// ============================================================================
// Theme Toggle — Dark / Light Mode
//
// How it works:
// 1. On page load, check localStorage for a saved theme preference.
// 2. If nothing is saved, check the browser's prefers-color-scheme setting.
// 3. Apply the resolved theme by setting data-theme on <body>.
// 4. When the user clicks the toggle button, flip the theme, apply it,
//    and save the new preference to localStorage.
//
// The CSS uses data-theme="dark" on <body> to switch custom properties.
// If no data-theme is set and no localStorage preference exists, the CSS
// falls back to @media (prefers-color-scheme: dark) for auto-detection.
// ============================================================================

(function () {
    'use strict';

    // The key we use in localStorage to remember the user's choice
    var STORAGE_KEY = 'crystal-tutorial-theme';

    // Determine the initial theme. Priority:
    // 1. Explicit localStorage value ("light" or "dark")
    // 2. System preference via matchMedia
    // 3. Default to light (CSS default)
    function getInitialTheme() {
        var saved = localStorage.getItem(STORAGE_KEY);
        if (saved === 'dark' || saved === 'light') {
            return saved;
        }

        // No saved preference — check system setting
        if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
            return 'dark';
        }

        return 'light';
    }

    // Apply a theme to the document by setting data-theme on <body>
    function applyTheme(theme) {
        document.body.setAttribute('data-theme', theme);
    }

    // Save the preference so it persists across page loads
    function saveTheme(theme) {
        try {
            localStorage.setItem(STORAGE_KEY, theme);
        } catch (e) {
            // localStorage might be unavailable (private browsing, etc.)
            // Fail silently — the toggle still works for the current session
        }
    }

    // Create the toggle button and insert it into the page.
    // Uses unicode characters for sun/moon icons so we don't need
    // any external icon libraries or image files.
    function createToggleButton() {
        var btn = document.createElement('button');
        btn.className = 'theme-toggle';
        btn.setAttribute('aria-label', 'Toggle dark/light mode');
        btn.setAttribute('title', 'Toggle dark/light mode');

        // Two spans: one for each icon. CSS controls which one is visible
        // based on the current data-theme value.
        btn.innerHTML =
            '<span class="icon-sun" aria-hidden="true">&#9788;</span>' +
            '<span class="icon-moon" aria-hidden="true">&#9789;</span>';

        btn.addEventListener('click', function () {
            // Read the current theme from the body attribute
            var current = document.body.getAttribute('data-theme');
            var next = (current === 'dark') ? 'light' : 'dark';

            applyTheme(next);
            saveTheme(next);
        });

        document.body.appendChild(btn);
    }

    // Initialize everything once the DOM is ready
    function init() {
        var theme = getInitialTheme();
        applyTheme(theme);
        createToggleButton();
    }

    // Run init when DOM is ready. If the script is loaded at the end of
    // <body> (which it should be), DOMContentLoaded may have already fired.
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
